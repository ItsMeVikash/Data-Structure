import java.util.Scanner;

public class InterpolationSearch {

	public static void main(String[] args) {
		int high, low = 0;
		int arr[] = new int[5];
		Scanner scanner = new Scanner(System.in);
		for (int i = 0; i < arr.length; i++) {
			arr[i] = scanner.nextInt();
		}
		high = arr.length - 1;
		System.out.println("Enter element to search\n");
		int x = scanner.nextInt();
		while (low <= high && x >= arr[low] && x <= arr[high]) {
			int pos = low + (((high - low) / (arr[high] - arr[low])) * (x - arr[low]));

			if (arr[pos] == x)
				System.out.println("Found at location\t" + pos);
			if (arr[pos] < x)
				low = pos + 1;
			else
				high = pos - 1;
		}
	}

}
