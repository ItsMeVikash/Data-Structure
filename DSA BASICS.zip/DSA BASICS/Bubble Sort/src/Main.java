import java.util.Scanner;

public class Main {

	public static void main(String[] args) {


		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter size of array");
		int size=scanner.nextInt();
		int arr[]=new int[size];
		System.out.println("Enter "+size+" elements one by one");
		for (int i = 0; i < arr.length; i++) {
			arr[i]=scanner.nextInt();
		}
		int temp;
		for (int i = 0; i < arr.length; i++) {
			for (int j = i+1; j < arr.length; j++) {
				if (arr[i]>arr[j]) {
					temp=arr[i];
					arr[i]=arr[j];
					arr[j]=temp;
				}
			}
		}
		for (int i = 0; i < arr.length; i++) {
			System.out.print(arr[i]+",");
		}

	}

}
