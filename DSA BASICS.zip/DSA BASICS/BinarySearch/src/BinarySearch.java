import java.util.Scanner;

public class BinarySearch {

	public static void main(String[] args) {

		int high, low = 0, mid;
		int arr[] = new int[8];
		Scanner scanner = new Scanner(System.in);
		for (int i = 0; i < arr.length; i++) {
			arr[i] = scanner.nextInt();
		}
		high = arr.length - 1;
		mid = high + low / 2;
		System.out.println("Enter element to be searched\n");
		int search = scanner.nextInt();
		if (low > high) {
			System.out.println("Element Not Found");
		} else {
			while (low <= high) {
				if (arr[mid] < search) {
					low = mid + 1;
				} else if (arr[mid] == search) {
					System.out.println("Element is found at index: " + mid);
					break;
				} else {
					high = mid - 1;
				}
				mid = (low + high) / 2;
			}
		}
	}

}
