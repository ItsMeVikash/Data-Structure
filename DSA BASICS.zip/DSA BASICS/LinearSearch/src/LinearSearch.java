import java.util.Scanner;

public class LinearSearch {

	public static void main(String[] args) {

		Scanner scanner = new Scanner(System.in);
		int arr[] = new int[5];
		System.out.println("Enter the Elements one by one\n");
		for (int i = 0; i < arr.length; i++) {
			arr[i] = scanner.nextInt();
		}
		System.out.println("Enter the Element to search\n");
		int search = scanner.nextInt();
		int flag = 0;
		for (int i = 0; i < arr.length; i++) {
			if (arr[i] == search) {
				flag = 1;
				break;
			}
		}
		if (flag == 0) {
			System.out.println("Not Found");
		} else {
			System.out.println("Found");
		}
		scanner.close();
	}

}
