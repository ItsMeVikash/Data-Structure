import java.util.Scanner;

public class Queueimplementation {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		char ch = 0;
		System.out.println("Enter the size of queue");
		int size = scanner.nextInt();
		Queue queue = new Queue(size);

		do {
			System.out.println("\n1. Insert\n");
			System.out.println("2. Delete\n");
			System.out.println("3. Exit\n");
			int choice = scanner.nextInt();
			switch (choice) {
			case 1:
				System.out.println("Enter integer to insert");
				queue.insert(scanner.nextInt());
				break;
			case 2:
				System.out.println("Removed Element = " + queue.remove());
				break;
			case 3:
				System.exit(0);
				break;

			default:
				System.out.println("Wrong Entry \n ");
				break;
			}
			/* display Queue */
			queue.display();
			System.out.println("\nDo you want to continue (Type y or n) \n");
			ch = scanner.next().charAt(0);
		} while (ch == 'y' || ch == 'Y');
		scanner.close();
	}

}
