import java.util.NoSuchElementException;

public class Queue {
	int arr[], front, rear, size, len;

	public Queue(int n) {
		size = n;
		len = 0;
		front = rear = -1;
		arr = new int[size];
	}

	public boolean isEmpty() {
		return front == -1;
	}

	public boolean isFull() {
		return front == 0 && rear == size - 1;
	}

	public void insert(int nextInt) {
		if (rear == -1) {
			rear = front = 0;
			arr[rear] = nextInt;
		} else if (rear + 1 >= size)
			throw new IndexOutOfBoundsException("Overflow Exception");

		else if (rear + 1 < size)
			arr[++rear] = nextInt;

		len++;
	}

	public int remove() {
		if (isEmpty()) {
			throw new NoSuchElementException("Underflow Exception");
		} else {
			len--;
			int element = arr[front];
			if (front == rear) {
				front = -1;
				rear = -1;
			} else
				front++;
			return element;
		}
	}
	public void display()
    {
        System.out.print("\nQueue = ");
        if (len == 0)
        {
            System.out.print("Empty\n");
            return ;
        }
        for (int i = front; i <= rear; i++)
            System.out.print(arr[i]+" ");
        System.out.println();        
    }

}
